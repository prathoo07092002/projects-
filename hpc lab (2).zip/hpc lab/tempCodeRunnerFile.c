ragma omp parallel
// {
//      printf("hello world %d",omp_get_thread_num);
// }